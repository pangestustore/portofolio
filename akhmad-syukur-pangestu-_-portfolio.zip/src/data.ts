/**
 * CV Data for Akhmad Syukur Pangestu
 */

export const portfolioData = {
  personalInfo: {
    fullName: "Akhmad Syukur Pangestu",
    firstName: "Akhmad",
    lastName: "Pangestu", // For the highlighted part
    title: "Web Back-End Developer & Data Analyst",
    email: "akhmadpangestuu@gmail.com",
    phone: "+62 895-8108-90800",
    linkedin: "https://www.linkedin.com/in/akhmad-syukur-pangestu/",
    location: "Sampit, Indonesia",
    portfolioUrl: "https://ais-dev-n63iifdihd4refvrxubzlh-739692898799.asia-east1.run.app", // Fallback
    profileSummary: "Passionate Informatics Engineering graduate specializing in information systems, data analysis, and technology-driven administration. Experience in developing scalable back-end systems and managing complex data workflows.",
    expertOn: "Specializing in Back-End Development and Data-Driven Insights, delivering efficient and innovative technical solutions.",
    collabInvite: "I thrive in collaborative environments and am always looking for new challenges to solve. Let's build something exceptional together."
  },
  education: [
    {
      institution: "Universitas Palangka Raya",
      degree: "S1 Teknik Informatika",
      period: "Aug 2021 – Jun 2025",
      details: "IPK 3.65 / 4.00"
    }
  ],
  experience: [
    {
      role: "Web Back-End Developer (MSIB Batch 6)",
      company: "PT Educa Sisfomedia Indonesia",
      period: "Feb – Jun 2024",
      description: "Developed web applications using Node.js, built RESTful APIs, and integrated MySQL/MongoDB databases for optimal performance.",
      achievements: [
        "Collaborated on industrial-grade Capstone Projects.",
        "Implemented complex programming logic and problem-solving strategies."
      ]
    },
    {
      role: "Digital Marketing & KOL Specialist",
      company: "PT Asadel Liamsindo Teknologi",
      period: "Jun – Sep 2024",
      description: "Managed communications and collaborations with Key Opinion Leaders (KOLs) and influencers to boost brand awareness.",
      achievements: [
        "Monitored campaign performance and analyzed audience engagement.",
        "Created digital marketing strategies for social media platforms."
      ]
    },
    {
      role: "Pengelola Fasilitas Umum",
      company: "Bapas Kelas II Sampit – Kemenimipas",
      period: "Nov 2025 – May 2026",
      description: "Managed office facilities and supported administrative tasks, including digital archiving and report preparation.",
      achievements: [
        "Handled office infrastructure and equipment maintenance.",
        "Managed digital correspondence using the SRIKANDI application."
      ]
    }
  ],
  academicExperience: [
    {
      role: "Lab Assistant - Algorithm & Programming (Pascal)",
      period: "Sep – Oct 2023",
      details: "Mentored students in Pascal basics and managed laboratory sessions."
    },
    {
      role: "Multimedia Lab Assistant",
      period: "Feb – Mar 2024",
      details: "Assisted students with Blender 3D, Adobe Premiere, and Adobe Animate."
    }
  ],
  projects: [
    {
      title: "Mobile JKN Review Analysis",
      type: "Thesis Project",
      description: "Implemented NLP using IndoBERT and RoBERTa to analyze sentiment and identify key topics from user reviews of the Mobile JKN app.",
      tech: ["Python", "NLP", "IndoBERT", "RoBERTa"]
    },
    {
      title: "Dental Clinic EMR System",
      type: "Web Application",
      description: "Developed a web-based Electronic Medical Record system with patient tracking, treatment history, and inventory management.",
      tech: ["Node.js", "Web Dev", "Database"]
    },
    {
      title: "Fruit Sales Information System",
      type: "Web Application",
      description: "Created a transaction management system for UD. Sumber Rezeki, handling product inventory and sales reporting.",
      tech: ["Web Development", "Database"]
    },
    {
      title: "Movie Ticket Reservation",
      type: "MSIB Internship Project",
      description: "Built a cinema ticket booking application featuring film selection, seat picking, and e-ticketing systems.",
      tech: ["Node.js", "Backend", "UX"]
    }
  ],
  skills: {
    technical: [
      { category: "Web Development", items: ["HTML", "CSS", "JavaScript", "jQuery", "PHP", "Node.js"] },
      { category: "Database", items: ["MySQL", "MongoDB"] },
      { category: "Data Analysis", items: ["Python", "Pandas", "Scikit-learn", "Jupyter", "Preprocessing"] },
      { category: "Tools", items: ["MS Office", "Design Tools", "Git"] }
    ],
    personal: ["Collaboration", "Effective Communication", "Leadership", "Problem Solving", "Critical Thinking", "Adaptive"]
  }
};
