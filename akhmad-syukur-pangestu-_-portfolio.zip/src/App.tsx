import { motion } from "motion/react";
import { portfolioData } from "./data";
import { 
  Github, 
  Linkedin, 
  Mail, 
  Download, 
  Menu, 
  ExternalLink, 
  Code2, 
  Database, 
  BarChart3, 
  Laptop,
  ArrowRight
} from "lucide-react";
import { useState, useEffect, ReactNode } from "react";

// --- Components ---

const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 w-full z-50 px-8 py-6 flex justify-between items-center backdrop-blur-sm bg-black/10">
      <div className="flex items-center space-x-4">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="font-display font-bold text-xl tracking-tighter"
        >
          AS.PANGESTU
        </motion.div>
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="hidden md:block text-xs font-mono text-zinc-500 tracking-widest uppercase"
        >
          {portfolioData.personalInfo.email}
        </motion.div>
      </div>
      <motion.button 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="p-2 hover:bg-zinc-900 rounded-full transition-colors"
      >
        <Menu className="w-6 h-6 text-white" />
      </motion.button>
    </nav>
  );
};

const Socials = () => {
  return (
    <div className="fixed left-8 bottom-12 z-40 hidden lg:flex flex-col space-y-6">
      <motion.a 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        href={portfolioData.personalInfo.linkedin} 
        target="_blank" 
        className="text-zinc-500 hover:text-accent transition-colors"
      >
        <Linkedin className="w-5 h-5" />
      </motion.a>
      <motion.a 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9 }}
        href={`mailto:${portfolioData.personalInfo.email}`}
        className="text-zinc-500 hover:text-accent transition-colors"
      >
        <Mail className="w-5 h-5" />
      </motion.a>
      <motion.a 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        href="#"
        className="text-zinc-500 hover:text-accent transition-colors"
      >
        <Github className="w-5 h-5" />
      </motion.a>
      <div className="w-[1px] h-20 bg-zinc-800 mx-auto" />
    </div>
  );
};

const SectionHeading = ({ children, subtitle }: { children: ReactNode, subtitle?: string }) => {
  return (
    <div className="mb-16">
      {subtitle && (
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-xs font-mono text-accent uppercase tracking-[0.3em] mb-4"
        >
          {subtitle}
        </motion.p>
      )}
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="font-display text-4xl md:text-6xl font-bold tracking-tight"
      >
        {children}
      </motion.h2>
    </div>
  );
}

const Hero = () => {
  return (
    <section className="relative min-height-[100vh] pt-32 pb-20 px-8 flex flex-col lg:flex-row items-center justify-between overflow-hidden">
      {/* Decorative Lights */}
      <div className="absolute top-[20%] left-[10%] w-[30vw] h-[30vw] bg-accent/10 rounded-full blur-[120px] -z-10 animate-pulse" />
      <div className="absolute bottom-[20%] right-[10%] w-[20vw] h-[20vw] bg-secondary/10 rounded-full blur-[100px] -z-10" />

      {/* Left content */}
      <div className="w-full lg:w-1/3 z-10 flex flex-col items-start text-left order-2 lg:order-1 mt-12 lg:mt-0">
        <motion.span 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-2xl font-light text-zinc-400 mb-2"
        >
          Hi,
        </motion.span>
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="font-display text-7xl md:text-8xl font-extrabold leading-[0.85] tracking-tighter uppercase mb-6"
        >
          {portfolioData.personalInfo.firstName}
          <br />
          <span className="text-accent">{portfolioData.personalInfo.lastName}</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-zinc-500 max-w-xs mb-8 font-light text-lg italic"
        >
          {portfolioData.personalInfo.title}
        </motion.p>
        <motion.button 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6 }}
          className="glow-btn bg-accent text-black font-bold py-4 px-10 rounded-full text-sm uppercase tracking-widest"
        >
          Hire Me
        </motion.button>
      </div>

      {/* Center Image */}
      <div className="w-full lg:w-2/5 flex justify-center items-center order-1 lg:order-2">
        <motion.div 
          initial={{ opacity: 0, scale: 0.8, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: "spring", damping: 20, stiffness: 100, delay: 0.2 }}
          className="relative w-full max-w-md aspect-[3/4] rounded-2xl overflow-hidden group"
        >
          <img 
            src={`https://picsum.photos/seed/gentleman-tech/800/1200`} // Placeholder for professional portrait
            alt={portfolioData.personalInfo.fullName}
            className="w-full h-full object-cover filter contrast-125 grayscale hover:grayscale-0 transition-all duration-1000 ease-in-out"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
          {/* Subtle glow rings */}
          <div className="absolute -top-4 -right-4 w-32 h-32 border border-accent/20 rounded-full animate-spin-slow" />
          <div className="absolute -bottom-10 -left-10 w-48 h-48 border border-secondary/20 rounded-full animate-reverse-spin-slow" />
        </motion.div>
      </div>

      {/* Right Content */}
      <div className="w-full lg:w-1/4 z-10 flex flex-col items-start lg:items-end text-left lg:text-right order-3 mt-12 lg:mt-0">
        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
          className="space-y-6"
        >
          <div className="space-y-1">
            <p className="text-xs font-mono text-accent uppercase tracking-widest">Expert on</p>
            <p className="text-xl font-light text-white leading-relaxed">
              {portfolioData.personalInfo.expertOn}
            </p>
          </div>
          <p className="text-zinc-500 font-light text-sm leading-relaxed max-w-xs ml-auto">
            {portfolioData.personalInfo.collabInvite}
          </p>
          <a href="#" className="inline-flex items-center space-x-2 text-sm font-medium hover:text-accent transition-colors group">
            <span>Download CV</span>
            <Download className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
            <div className="h-[1px] w-0 group-hover:w-full bg-accent transition-all duration-300" />
          </a>
        </motion.div>
      </div>

      {/* Background Micro Details */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-2 h-2 bg-accent rounded-full animate-ping" />
        <div className="absolute bottom-1/3 left-1/4 w-1.5 h-1.5 bg-secondary rounded-full animate-pulse" />
      </div>
    </section>
  );
};

const Experience = () => {
  return (
    <section id="experience" className="py-32 px-8 max-w-7xl mx-auto">
      <SectionHeading subtitle="Professional Journey">Experience</SectionHeading>
      <div className="space-y-12">
        {portfolioData.experience.map((exp, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="group relative grid grid-cols-1 md:grid-cols-[200px_1fr] gap-4 md:gap-12 pb-12 border-b border-zinc-900 last:border-0"
          >
            <div className="text-zinc-500 font-mono text-sm uppercase tracking-tighter">
              {exp.period}
            </div>
            <div>
              <h3 className="text-2xl font-display font-bold group-hover:text-accent transition-colors flex items-center gap-3">
                {exp.role}
                <span className="text-sm font-medium text-zinc-600 bg-zinc-900 px-3 py-1 rounded-full">{exp.company}</span>
              </h3>
              <p className="mt-4 text-zinc-400 font-light leading-relaxed max-w-2xl">
                {exp.description}
              </p>
              <ul className="mt-6 flex flex-wrap gap-x-8 gap-y-2">
                {exp.achievements.map((ach, i) => (
                  <li key={i} className="flex items-center space-x-2 text-xs text-zinc-500 italic">
                    <div className="w-1 h-1 bg-accent rounded-full" />
                    <span>{ach}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const Projects = () => {
  return (
    <section id="projects" className="py-32 px-8 max-w-7xl mx-auto">
      <SectionHeading subtitle="Selected Works">Projects</SectionHeading>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {portfolioData.projects.map((project, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="group block relative bg-zinc-950/50 border border-zinc-900 rounded-3xl p-8 hover:border-accent/30 transition-all duration-500 overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-8 text-zinc-800 group-hover:text-accent transition-colors group-hover:rotate-45 duration-500">
              <ExternalLink className="w-8 h-8" />
            </div>
            <div className="space-y-4 relative z-10">
              <p className="text-xs font-mono text-zinc-600 uppercase tracking-widest">{project.type}</p>
              <h3 className="text-3xl font-display font-bold tracking-tight">{project.title}</h3>
              <p className="text-zinc-500 font-light leading-relaxed">{project.description}</p>
              <div className="flex flex-wrap gap-2 pt-4">
                {project.tech.map((t, i) => (
                  <span key={i} className="text-[10px] font-mono text-zinc-400 border border-zinc-800 px-3 py-1 rounded-full bg-zinc-900/50">
                    {t}
                  </span>
                ))}
              </div>
            </div>
            {/* Hover card glow */}
            <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-accent to-secondary opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const Skills = () => {
  const getIcon = (cat: string) => {
    switch(cat) {
      case "Web Development": return <Laptop className="w-6 h-6 text-accent" />;
      case "Database": return <Database className="w-6 h-6 text-secondary" />;
      case "Data Analysis": return <BarChart3 className="w-6 h-6 text-orange-400" />;
      default: return <Code2 className="w-6 h-6 text-zinc-400" />;
    }
  }

  return (
    <section id="skills" className="py-32 px-8 max-w-7xl mx-auto border-t border-zinc-900">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        <div className="lg:col-span-1">
          <SectionHeading subtitle="Technical Arsenal">Expertise</SectionHeading>
          <p className="text-zinc-500 font-light leading-relaxed mb-8">
            My technical stack is built around efficiency and scalability, spanning across modern web frameworks and data processing tools.
          </p>
          <div className="flex flex-wrap gap-3">
            {portfolioData.skills.personal.map((s, i) => (
              <span key={i} className="text-xs font-medium text-zinc-400 border border-zinc-900 px-4 py-2 rounded-xl bg-zinc-900/20">
                {s}
              </span>
            ))}
          </div>
        </div>
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
          {portfolioData.skills.technical.map((skill, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 bg-zinc-950 border border-zinc-900 rounded-[2rem] flex flex-col items-start space-y-6 hover:shadow-2xl hover:shadow-accent/5 transition-all"
            >
              <div className="p-4 bg-zinc-900 rounded-2xl">
                {getIcon(skill.category)}
              </div>
              <div>
                <h4 className="font-display font-bold text-xl mb-4">{skill.category}</h4>
                <div className="flex flex-wrap gap-2">
                  {skill.items.map((item, i) => (
                    <span key={i} className="text-xs font-mono text-zinc-500">{item}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-20 px-8 border-t border-zinc-900 text-center">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="space-y-4">
          <h2 className="font-display text-4xl md:text-7xl font-bold tracking-tight">Let's build something <span className="text-accent underline decoration-1 underline-offset-8">great</span>.</h2>
          <p className="text-zinc-500 font-light text-xl">akhmadpangestuu@gmail.com</p>
        </div>
        <div className="flex justify-center space-x-12 pb-12">
          {['LinkedIn', 'Github', 'Instagram', 'Medium'].map((social) => (
            <a key={social} href="#" className="text-sm font-mono text-zinc-600 hover:text-white transition-colors">{social}</a>
          ))}
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-zinc-900/50 text-xs font-mono text-zinc-800">
          <p>© 2026 AKHMAD SYUKUR PANGESTU. ALL RIGHTS RESERVED.</p>
          <p className="mt-4 md:mt-0">DESIGNED BY AI IN HOUSE</p>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  if (!isLoaded) return null;

  return (
    <div className="min-h-screen font-sans selection:bg-accent selection:text-black">
      <Navbar />
      <Socials />
      
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <Hero />
        <Experience />
        <Projects />
        <Skills />
        <Footer />
      </motion.div>

      {/* "Let's Chat" Fixed Element */}
      <motion.button 
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed right-8 bottom-8 z-50 flex items-center space-x-3 bg-white text-black py-4 px-6 rounded-full font-bold shadow-2xl hover:bg-accent transition-colors"
      >
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
        <span className="text-xs uppercase tracking-widest font-display">Let's Chat</span>
        <ArrowRight className="w-4 h-4" />
      </motion.button>
    </div>
  );
}
